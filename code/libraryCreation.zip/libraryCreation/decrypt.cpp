using namespace std;

int decrypt(int i){
   return i-3;
}
