//Function prototypes
//int encrypt(int );
//int decrypt(int );
#include "./encrypt.h"
#include "./decrypt.h"
