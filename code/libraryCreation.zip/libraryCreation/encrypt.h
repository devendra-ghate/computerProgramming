//Function prototypes
int encrypt(int );
