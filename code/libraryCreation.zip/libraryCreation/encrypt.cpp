using namespace std;

int encrypt(int i){
   return i+3;
}
