//Function prototypes
int decrypt(int );
